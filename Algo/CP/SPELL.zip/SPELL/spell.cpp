//Dai Ca Di Hoc
#include <bits/stdc++.h>
#define sz(x) int(x.size())
#define all(x) x.begin(),x.end()
#define reset(x) memset(x, 0,sizeof(x))
#define Rep(i,n) for(int (i)=0;(i)<(int)(n);++(i))
#define For(i,l,u) for(int (i)=(int)(l);(i)<=(int)(u);++(i))
#define MIN(x,y) if (x > (y)) x = (y)
#define MAX(x,y) if (x < (y)) x = (y)
#define PB push_back
#define mp make_pair
#define F first
#define S second
#define maxn 305
#define MOD 1000000007
#define remain(x) if (x > MOD) x -= MOD
#define pii pair<int, int>
#define vi vector<int>
#define vii vector< pii >
#define bit(x, i) (((x) >> (i)) & 1)
#define Task "spell"

using namespace std;

typedef long long ll;
typedef long double ld;

short dx[4] = {0, 0, -1, 1};
short dy[4] = {-1, 1, 0, 0};

struct data{
    int p, x, y;
};

int  sx, sy, sp, m, n;
string pattern;
char a[maxn][maxn];
data qu[maxn*maxn*maxn*2];

int dist[maxn][maxn][maxn];

void BFS(){
    //reset(dist);
    For(i, 0, sp) For(j, 1, m) For(k, 1, n) dist[i][j][k] = maxn*maxn;

    int L = 1, R = 0;
    For(i, 1, m) For(j, 1, n)
        if (a[i][j] == pattern[0]){
            dist[1][i][j] = 1;
            qu[++R] = {1, i, j};
        }

    while (L <= R){
        int p = qu[L].p;
        int x = qu[L].x;
        int y = qu[L++].y;
        int dcur = dist[p][x][y];
        if (p == sp){
            cout << dcur << endl;
            return;
        }
        for (int i = 0; i < 4; i++){
            int u = x + dx[i];
            int v = y + dy[i];
            if (u <= 0 || u > m || v <= 0 || v > n) continue;
            int q = p + (a[u][v] == pattern[p]);
            if (dist[q][u][v] > dcur + 1){
                dist[q][u][v] = dcur + 1;
                qu[++R] = {q, u, v};
            }
        }
    }
}

void Solve(){
    cin >> m >> n >> sp;
    cin >> pattern;
    For (i, 1, m) For(j, 1, n) cin >> a[i][j];
    BFS();
}

int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    freopen(Task".inp", "r", stdin);
    freopen(Task".out", "w", stdout);
    Solve();
    return 0;
}

